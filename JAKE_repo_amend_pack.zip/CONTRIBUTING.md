# Contributing

Thank you for your interest in J.A.K.E.

## How to contribute

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## Areas we welcome help on

- Knowledge extraction
- Graph modelling
- Markdown wiki generation
- Local-first AI workflows
- Documentation
- Demo datasets

## Style

Keep the project:

- local-first
- human-readable
- simple to run
- useful for decision intelligence
