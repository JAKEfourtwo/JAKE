# Roadmap

## Phase 1 — Foundation

- [x] Repo structure
- [x] README positioning
- [x] Sample raw file
- [x] Sample wiki pages
- [x] Sample graph output
- [x] Basic ingest/query/lint commands

## Phase 2 — Real Extraction

- [ ] Entity extraction
- [ ] Concept extraction
- [ ] Relationship extraction
- [ ] Source citation tracking

## Phase 3 — Knowledge Graph

- [ ] Graph builder
- [ ] Relationship weighting
- [ ] Timeline-aware graph updates
- [ ] Contradiction detection

## Phase 4 — Intelligence Layer

- [ ] Natural language query interface
- [ ] Multi-document synthesis
- [ ] Insight generation
- [ ] Briefing note generation

## Phase 5 — Product Layer

- [ ] Web dashboard
- [ ] Obsidian integration
- [ ] CLI command: `jake`
- [ ] Export to PDF / markdown briefing
