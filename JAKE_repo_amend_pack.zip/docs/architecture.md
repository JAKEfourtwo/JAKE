# Architecture

J.A.K.E uses a layered architecture.

```text
Raw Sources
   ↓
Extraction Layer
   ↓
Wiki Layer
   ↓
Knowledge Graph Layer
   ↓
Query + Recall Layer
   ↓
Decision Intelligence
```

## 1. Raw Sources

Inputs can include:

- PDFs
- articles
- speeches
- transcripts
- notes
- web clips
- meeting summaries

## 2. Extraction Layer

The system extracts:

- facts
- entities
- concepts
- themes
- relationships
- timeline signals

## 3. Wiki Layer

Markdown pages are created under:

```text
wiki/sources/
wiki/entities/
wiki/concepts/
wiki/synthesis/
```

This makes the knowledge base human-readable and editable.

## 4. Knowledge Graph Layer

Entities and concepts are represented as nodes.  
Relationships are represented as edges.

Example:

```json
{
  "from": "Singapore",
  "to": "AI Governance",
  "relationship": "focuses_on"
}
```

## 5. Query + Recall Layer

Users ask questions in natural language.  
J.A.K.E searches the wiki and graph, then synthesizes an answer.

## 6. Decision Intelligence

The final output is not just retrieved text.  
It is structured insight that helps decision-makers understand what matters.
