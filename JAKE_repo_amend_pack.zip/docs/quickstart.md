# Quickstart

## 1. Clone the repo

```bash
git clone https://github.com/JAKEfourtwo/JAKE.git
cd JAKE
```

## 2. Install dependencies

```bash
npm install
```

## 3. Run ingest

```bash
npm run ingest
```

## 4. Run query

```bash
npm run query
```

## 5. Run lint

```bash
npm run lint
```

## Optional Local Tools

For a fuller local-first setup, you may use:

- Obsidian for markdown vault browsing
- Ollama for local LLMs
- qmd for local markdown search
- Web Clipper for collecting articles
