# Philosophy

J.A.K.E is built on a simple belief:

> Knowledge should compound.

Most AI systems answer questions in isolation.  
J.A.K.E is designed to build memory over time.

## Principles

### 1. Local-first

The user should control their knowledge base.

### 2. Human-readable

Knowledge should not be trapped inside an opaque vector database.

### 3. Structured before intelligent

Good intelligence requires structured memory.

### 4. Graph over folders

Important knowledge is relational.

### 5. Decision-ready outputs

The goal is not more information.  
The goal is better judgment.
