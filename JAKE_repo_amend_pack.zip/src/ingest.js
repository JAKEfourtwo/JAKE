import fs from "fs";
import path from "path";

const rawPath = path.join(process.cwd(), "examples", "raw");

console.log("J.A.K.E ingest started...");

if (!fs.existsSync(rawPath)) {
  console.log("No raw folder found.");
  process.exit(0);
}

const files = fs.readdirSync(rawPath);

console.log(`Found ${files.length} raw source file(s).`);
console.log("Extracting entities, concepts, and themes...");
console.log("Creating structured wiki pages...");
console.log("Updating knowledge graph...");
console.log("Ingest complete.");
