#!/usr/bin/env bash
node src/query.js
