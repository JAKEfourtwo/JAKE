#!/usr/bin/env bash
node src/ingest.js
