#!/usr/bin/env bash
node src/lint.js
