# AI Governance

## Definition

AI Governance refers to frameworks, policies, and standards that shape how artificial intelligence is developed, deployed, and monitored.

## Key Themes

- trust
- safety
- accountability
- cross-border standards
- regulatory clarity

## Related Entities

- [[Singapore]]
- [[ASEAN]]
- [[United States]]
- [[China]]
