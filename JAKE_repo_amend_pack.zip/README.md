# J.A.K.E — Janus AI Knowledge Engine

> Local-first AI Knowledge Graph OS that turns raw information into structured, compounding intelligence.

J.A.K.E is a personal AI knowledge engine built around the **LLM Wiki pattern**.  
It helps transform raw documents, speeches, notes, articles, and transcripts into structured wiki pages, connected knowledge graphs, and decision-ready intelligence.

## Why J.A.K.E

Most knowledge systems store information.  
J.A.K.E structures it.

Traditional RAG retrieves text chunks. J.A.K.E builds a living knowledge base that compounds over time.

## Core Workflow

```text
Raw Sources → Extraction → Wiki Pages → Knowledge Graph → Query + Recall
```

## Key Capabilities

- **Knowledge Extraction** — extracts entities, concepts, facts, and relationships
- **Structured Wiki Layer** — creates human-readable markdown pages
- **Knowledge Graph Layer** — maps people, organisations, concepts, and themes
- **Semantic Query Layer** — answers questions using stored knowledge
- **Integrity Layer** — checks stale data, contradictions, orphan pages, and broken links

## Example Use Case

A public figure, institution, or company can load historical speeches, articles, meeting notes, reports, and public documents into J.A.K.E.

J.A.K.E then helps answer questions such as:

- What themes have changed over time?
- Which entities are repeatedly connected?
- What narratives are emerging?
- Where are the contradictions?
- What should a decision-maker pay attention to?

## Repository Structure

```text
JAKE/
├── docs/                  # Architecture and setup documentation
├── examples/              # Sample raw files, wiki pages, and graph output
├── src/                   # Minimal prototype logic
├── scripts/               # Shell commands for ingest/query/lint
├── assets/                # Product images and visual assets
├── README.md
├── ROADMAP.md
├── CONTRIBUTING.md
├── LICENSE
├── package.json
└── .gitignore
```

## Quickstart

```bash
git clone https://github.com/JAKEfourtwo/JAKE.git
cd JAKE
npm install
npm run ingest
npm run query
```

## Project Status

This is an early prototype repository for the J.A.K.E concept.

Current focus:

- Local-first knowledge architecture
- Structured wiki generation
- Graph-based knowledge representation
- Decision-intelligence positioning

## Positioning

J.A.K.E is not just a second brain.

It is a **Knowledge Graph Layer** for people and institutions that need structured memory, fast recall, and better decision intelligence.

## License

MIT
